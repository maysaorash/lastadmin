import React from "react";

export function Demo5Dashboard() {
    return <></>;
}
